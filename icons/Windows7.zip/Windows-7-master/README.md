# Windows Se7en Icon Theme
### Port of the original Win2-7 icon theme adjusted to work with GTK 3.18 +

![folder](https://github.com/B00merang-Artwork/Windows-7/blob/master/filesystems/folder.png)
---

Mint Update tray icon is not in icon folder of any themes (or I don't know about it?), because of this to change this icon i replaced icons in apllet system folder, in my case /usr/share/cinnamon/applets/notifications@cinnamon.org/icons
and you need to do this carefully and make a backup before doing this
Icons that i replaced, in file "[icons.tar.gz](https://drive.google.com/file/d/1oGI6qE_cSSLmhMoSmMhWOopIQR0Q7N8S/view?usp=sharing)"


Credits:
- https://www.gnome-look.org/content/show.php/Win2-7+Pack?content=113264
- Xopek-Endurance (added symbolic icons for newer Cinnamon versions)
